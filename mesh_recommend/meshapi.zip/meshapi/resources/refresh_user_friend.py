# -*- coding: UTF-8 -*-

import numpy as np
import pandas as pd
import sys
sys.path.append("..")
from common.redshiftpool import RedShift
from common.config import RedisDBConfig
import redis



class RefreshFriend(object):
    """docstring for RefreshFriend"""
    def __init__(self):
        super(RefreshFriend, self).__init__()
        self.redshift = RedShift()
        self.userFriendPrex = 'rec_user_friend_' #记录用户的好友列表 （set）
        
    def loadFriendData(self):
        """
        从redshift加载好友信息
        """
        sql = "select userid,oppositeuserid from meshmatch_friend_prod;"
        sqlResult = self.redshift.getAll(sql)
        return sqlResult

    def friendInit(self):
        """
        预处理数据
        """
        r = redis.Redis(host=RedisDBConfig.HOST, port=RedisDBConfig.PORT)
        p = r.pipeline()

        friend = self.loadFriendData() #用户好友信息

        for i in friend:
            p.sadd(self.userFriendPrex + i[0], i[1])
            p.sadd(self.userFriendPrex + i[1], i[0])
        p.execute()


if __name__ == '__main__':
    rf = RefreshFriend()
    rf.friendInit()


